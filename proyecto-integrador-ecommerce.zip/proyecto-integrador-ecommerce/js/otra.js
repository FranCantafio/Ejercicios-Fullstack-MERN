function startOtra(){
    console.log("Otra cargada.");
}
