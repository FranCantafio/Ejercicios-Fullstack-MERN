function startNosotros(){
    console.log("Nosotros cargado.");
}
