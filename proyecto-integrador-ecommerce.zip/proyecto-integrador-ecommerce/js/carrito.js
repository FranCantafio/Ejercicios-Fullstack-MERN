function startCarrito(){
    console.log("Carrito cargado (aquí podrías renderizar productos del carrito).");
}
