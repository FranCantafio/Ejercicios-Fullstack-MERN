function startContacto(){
    console.log("Contacto cargado (agregar validación de formulario si deseas).");
}
